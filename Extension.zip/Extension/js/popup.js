$(document).ready(e => {
    openLastWindow();
    $("#feedbackform").submit((e) => {
        e.preventDefault();
        console.log($("#feedbackform").serialize());
        showFeedbackResponse("success", "Thanks for your feedback!");
        $("#feedbackform")[0].reset();

        chrome.identity.getAuthToken({interactive: true}, function(token) {
            console.log(token);
        });
    });
});

function showFeedbackResponse(type, message){
    let append = `<h4 class="text-center text-${type}">${message}</h4>`;
    $("#feedback_message").show();
    $("#feedback_message").append(append).fadeOut(5000, () => {
        $("#feedback_message").html("");
    });
}

function openLastWindow(){
    return new Promise(resolve => {
        chrome.storage.local.get(["lastWindow"], function (chromeData){
            let lastWindow = chromeData.lastWindow;
            if(lastWindow){
                openWindow(lastWindow);
            } else {
                openWindow("recent");
            }
            $(".windowTitle").click(function() {
                let windowName = $(this).attr("openWindow");
                log(windowName);
                openWindow(windowName)
            });
        }); 
    })
}

function openWindow(windowName){
    $(".cp-body").hide();
    $(".windowTitle").removeClass("active");
    $(`#${windowName}WindowTitle`).addClass("active");
    $(`#${windowName}ProductWindow`).show();
    $(`#${windowName}-0`).trigger( "click" );
    chrome.storage.local.set({ lastWindow: windowName });
    chrome.storage.local.set({ lastSelectedId: "" });
}