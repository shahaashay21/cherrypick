window.onload = function() {
    document.querySelector('button').addEventListener('click', function() {
        
    });
};